Micro Python documentation and references
=========================================

.. toctree::

   quickref.rst
   general.rst
   tutorial/index.rst
   library/index.rst
   hardware/index.rst
   license.rst
   contents.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
