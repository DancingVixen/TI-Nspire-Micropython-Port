:mod:`usocket` -- socket module
===============================

.. module:: usocket
   :synopsis: socket module

Socket functionality.

Functions
---------

.. function:: getaddrinfo(host, port)


.. function:: socket(family=AF_INET, type=SOCK_STREAM, fileno=-1)

   Create a socket.
