char *prompt(char *p);

